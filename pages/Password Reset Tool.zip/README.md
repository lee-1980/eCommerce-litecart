	    __    _ __       ______           __
	   / /   (_) /____  / ____/___ ______/ /_
	  / /   / / __/ _ \/ /   / __ `/ ___/ __/
	 / /___/ / /_/  __/ /___/ /_/ / /  / /_
	/_____/_/\__/\___/\____/\__,_/_/   \__/
	                      www.litecart.net

################
# Instructions #
################

1. Always backup data before making changes to your store.

2. Upload the file password_reset_tool.inc.php to the corresponding path of your LiteCart installation.

3. Browse to http://www.yourdomain.com/index.php/password_reset_tool

Done!
